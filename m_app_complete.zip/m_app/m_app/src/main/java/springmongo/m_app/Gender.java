package springmongo.m_app;

public enum Gender {
	MALE, FEMALE 
}
